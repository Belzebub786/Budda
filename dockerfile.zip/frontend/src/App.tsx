import { useState } from 'react'

function App() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [race, setRace] = useState('Nord')
  const [message, setMessage] = useState('')

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    
    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, race })
      })
      
      const data = await response.json()
      if (response.ok) {
        setMessage(`Успех: ${data.message}`)
      } else {
        setMessage(`Ошибка: ${data.message || data}`)
      }
    } catch (err) {
      setMessage('Ошибка соединения с сервером')
    }
  }

  return (
    <div style={{ maxWidth: '400px', margin: '50px auto', fontFamily: 'sans-serif' }}>
      <h2>Регистрация в Скайриме</h2>
      <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <input 
          type="text" placeholder="Имя героя" value={username} 
          onChange={e => setUsername(e.target.value)} required 
        />
        <input 
          type="password" placeholder="Пароль" value={password} 
          onChange={e => setPassword(e.target.value)} required 
        />
        <select value={race} onChange={e => setRace(e.target.value)}>
          <option value="Nord">Норд</option>
          <option value="Khajiit">Каджит</option>
          <option value="Argonian">Аргонианин</option>
          <option value="Dunmer">Данмер</option>
        </select>
        <button type="submit">Вступить в Соратники</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  )
}

export default App