import react from '@vitejs/plugin-react'
import { Server } from 'http'
import { defineConfig } from 'vite'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server:{
port:5173,
proxy: {
  '/api' : {target: 'htpp://localhost:8080',changeOrigin:true}
}
  }
})